Please place JAR file into the folder that contains the out.


How to create a portfolio of 3 stocks:
1. Start the program
2. Enter '1' to add stock data for a ticker of your choosing
3. Repeat step 2 two more times to get a total of 3 stocks loaded in the program
4. Enter '5' to create a new portfolio
5. Follow the instructions, and add your stocks. The portfolio will be created with 3 stocks in it

How to create a portfolio of 2 stocks and querying the value:
1. Start the program
2. Enter '1' to add stock data for a ticker of your choosing
3. Repeat step 2 one more time to get a total of 2 stocks loaded in the program
4. Enter '5' to create a new portfolio
5. Follow the instructions, and add your stocks. The portfolio will be created with 2 stocks in it
6. Enter '7' and follow the instructions to get the portfolio value. The program will output a value for you.

If our program runs out of requests, we direct the user to use these example stocks.
SUPPORTED OFFLINE STOCKS:
- Amazon
- Google
- Meta
- Netflix
- Apple
