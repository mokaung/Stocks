package controller;

import java.io.File;
import java.io.IOException;

public interface IParseXml {

  void convertXmlToPortfolio(File file) throws IOException;
}
