package model.performance;

import org.junit.Test;

import static org.junit.Assert.*;

public class PortfolioPerformanceTest {

  @Test
  public void getPerformance() {
  }
}