package view;

/**
 * Interface for the views of the program.
 */
public interface IViews {
}
