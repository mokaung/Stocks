package controller.command;

import model.IModel2;

public interface ICommand2 {

  void run(IModel2 model);
}
